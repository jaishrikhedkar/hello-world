$( document ).ready(function() {

async function loadIntoTable(url, table)
{
	const tableHead = table.querySelector("thead");
	const tableBody = table.querySelector("tbody");
	const response = await fetch(url);
	
	const data = await response.json();
	 var head ="";
	var temp = "";
	for(var posts=0 ; posts < data.length; posts++){
		
		
		temp += "<tr>";
            temp += "<td>" + data[posts].id + "</td>";
            temp += "<td>" + data[posts].title + "</td>";
            
	}
	head += "<tr>";
            head += "<th>" + "id "+ "</th>";
            head += "<th>" + "title" + "</th>";
	tableBody.innerHTML = temp;
	tableHead.innerHTML = head;
}
loadIntoTable("https://jsonplaceholder.typicode.com/posts", document.querySelector("table"));

      
});